import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import javax.sound.sampled.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class FlappyBird extends JPanel implements ActionListener, KeyListener {
    int boardWidth = 360;
    int boardHeight = 640;

    //images
    Image backgroundImg;
    Image birdImg;
    Image topPipeImg;
    Image bottomPipeImg;

    //bird class
    int birdX = boardWidth/8;
    int birdY = boardHeight/2;
    int birdWidth = 70;  // Increased size for better visibility
    int birdHeight = 40; // Made it square for face images

    class Bird {
        int x = birdX;
        int y = birdY;
        int width = birdWidth;
        int height = birdHeight;
        Image img;

        Bird(Image img) {
            this.img = img;
        }
    }

    //pipe class
    int pipeX = boardWidth;
    int pipeY = 0;
    int pipeWidth = 64;  //scaled by 1/6
    int pipeHeight = 512;

    class Pipe {
        int x = pipeX;
        int y = pipeY;
        int width = pipeWidth;
        int height = pipeHeight;
        Image img;
        boolean passed = false;

        Pipe(Image img) {
            this.img = img;
        }
    }

    //game logic
    Bird bird;
    int velocityX = -4; //move pipes to the left speed (simulates bird moving right)
    int velocityY = 0; //move bird up/down speed.
    int gravity = 1;

    // Level system variables
    int level = 1;
    int baseGravity = 1;
    int basePipeSpeed = -4;

    ArrayList<Pipe> pipes;
    Random random = new Random();

    Timer gameLoop;
    Timer placePipeTimer;
    boolean gameOver = false;
    double score = 0;

    // Store multiple backgrounds and pipe images for different levels
    Image[] backgrounds;
    Image[] topPipes;
    Image[] bottomPipes;
    int currentBgIndex = 0;

    FlappyBird() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        // setBackground(Color.blue);
        setFocusable(true);
        addKeyListener(this);

        //load images - multiple backgrounds and pipes for different levels
        backgrounds = new Image[3];
        topPipes = new Image[3];
        bottomPipes = new Image[3];

        // Load multiple backgrounds (you can add more)
        backgrounds[0] = loadImageSafely("./flappybirdbg.png", Color.CYAN);
        backgrounds[1] = loadImageSafely("./flappybirdbg2.png", new Color(255, 200, 150)); // Orange tint
        backgrounds[2] = loadImageSafely("./flappybirdbg3.png", new Color(50, 50, 80)); // Dark blue/purple

        // Load multiple pipe sets
        topPipes[0] = loadImageSafely("./toppipe.png", Color.GREEN);
        topPipes[1] = loadImageSafely("./toppipe2.png", Color.RED);
        topPipes[2] = loadImageSafely("./toppipe3.png", new Color(139, 69, 19)); // Brown

        bottomPipes[0] = loadImageSafely("./bottompipe.png", Color.GREEN);
        bottomPipes[1] = loadImageSafely("./bottompipe2.png", Color.RED);
        bottomPipes[2] = loadImageSafely("./bottompipe3.png", new Color(139, 69, 19)); // Brown

        // Set initial images
        backgroundImg = backgrounds[0];
        topPipeImg = topPipes[0];
        bottomPipeImg = bottomPipes[0];

        // Try to load custom bird image from user's selection
        birdImg = selectBirdImage();

        //bird
        bird = new Bird(birdImg);
        pipes = new ArrayList<Pipe>();

        //place pipes timer
        placePipeTimer = new Timer(1500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to be executed
                placePipes();
            }
        });
        placePipeTimer.start();

        //game timer
        gameLoop = new Timer(1000/60, this); //how long it takes to start timer, milliseconds gone between frames
        gameLoop.start();
    }

    // New method to load images safely with fallback colors
    Image loadImageSafely(String path, Color fallbackColor) {
        try {
            java.net.URL imgURL = getClass().getResource(path);
            if (imgURL != null) {
                return new ImageIcon(imgURL).getImage();
            }
        } catch (Exception e) {
            System.err.println("Could not load image: " + path);
        }

        // Create a colored rectangle as fallback
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(
                64, 512, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setColor(fallbackColor);
        g2d.fillRect(0, 0, 64, 512);
        g2d.dispose();
        return img;
    }

    // New method to select bird image from computer
    Image selectBirdImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Bird Image");

        // Set file filter to only show image files
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                if (f.isDirectory()) {
                    return true;
                }
                String name = f.getName().toLowerCase();
                return name.endsWith(".png") || name.endsWith(".jpg") ||
                        name.endsWith(".jpeg") || name.endsWith(".gif") ||
                        name.endsWith(".bmp");
            }

            public String getDescription() {
                return "Image Files (*.png, *.jpg, *.jpeg, *.gif, *.bmp)";
            }
        });

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                Image customImage = ImageIO.read(selectedFile);
                if (customImage != null) {
                    System.out.println("Custom bird image loaded: " + selectedFile.getName());
                    return customImage;
                }
            } catch (IOException e) {
                System.err.println("Error loading custom bird image: " + e.getMessage());
            }
        }

        // If no image selected or error occurred, use default
        System.out.println("Using default bird image");
        return new ImageIcon(getClass().getResource("./flappybird.png")).getImage();
    }

    void playSound(String soundFile) {
        new Thread(() -> {
            try {
                File file = new File(soundFile);
                if (!file.exists()) {
                    System.err.println("Sound file not found: " + soundFile);
                    return;
                }

                AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                clip.start();

                // Wait for the clip to finish playing
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        clip.close();
                    }
                });
            } catch (Exception e) {
                System.err.println("Error playing sound: " + soundFile);
                System.err.println("Make sure the file is in WAV format!");
                e.printStackTrace();
            }
        }).start();
    }

    void placePipes() {
        //(0-1) * pipeHeight/2.
        // 0 -> -128 (pipeHeight/4)
        // 1 -> -128 - 256 (pipeHeight/4 - pipeHeight/2) = -3/4 pipeHeight
        int randomPipeY = (int) (pipeY - pipeHeight/4 - Math.random()*(pipeHeight/2));
        int openingSpace = boardHeight/4;

        Pipe topPipe = new Pipe(topPipeImg);
        topPipe.y = randomPipeY;
        pipes.add(topPipe);

        Pipe bottomPipe = new Pipe(bottomPipeImg);
        bottomPipe.y = topPipe.y  + pipeHeight + openingSpace;
        pipes.add(bottomPipe);
    }


    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        //background
        g.drawImage(backgroundImg, 0, 0, this.boardWidth, this.boardHeight, null);

        //bird - scaled to fit properly
        g.drawImage(bird.img, bird.x, bird.y, bird.width, bird.height, null);

        //pipes
        for (int i = 0; i < pipes.size(); i++) {
            Pipe pipe = pipes.get(i);
            g.drawImage(pipe.img, pipe.x, pipe.y, pipe.width, pipe.height, null);
        }

        //score and level display
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.BOLD, 32));

        if (gameOver) {
            g.drawString("Game Over: " + String.valueOf((int) score), 10, 35);
            g.setFont(new Font("Arial", Font.PLAIN, 20));
            g.drawString("Level: " + level, 10, 65);
        }
        else {
            g.drawString(String.valueOf((int) score), 10, 35);
            g.setFont(new Font("Arial", Font.PLAIN, 20));
            g.drawString("Level: " + level, 10, 65);
        }

    }

    public void move() {
        //bird
        velocityY += gravity;
        bird.y += velocityY;
        bird.y = Math.max(bird.y, 0); //apply gravity to current bird.y, limit the bird.y to top of the canvas

        //pipes
        for (int i = 0; i < pipes.size(); i++) {
            Pipe pipe = pipes.get(i);
            pipe.x += velocityX;

            if (!pipe.passed && bird.x > pipe.x + pipe.width) {
                score += 0.5; //0.5 because there are 2 pipes! so 0.5*2 = 1, 1 for each set of pipes
                pipe.passed = true;

                // Check for level up every 10 points
                checkLevelUp();
            }

            if (collision(bird, pipe)) {
                if (!gameOver) {
                    playSound("maka.wav"); // Play hit sound ONLY on pipe collision
                }
                gameOver = true;
            }
        }

        if (bird.y > boardHeight) {
            // Sound removed here - no sound when bird falls off screen
            gameOver = true;
        }
    }

    // New method to check and handle level ups
    void checkLevelUp() {
        int newLevel = ((int) score / 10) + 1; // Level up every 10 points

        if (newLevel > level && newLevel <= 3) { // Max level 3
            level = newLevel;

            // Increase difficulty
            gravity = baseGravity + (level - 1); // Gravity increases by 1 per level
            velocityX = basePipeSpeed - (level - 1); // Pipes move faster

            // Change visuals
            currentBgIndex = (level - 1) % backgrounds.length;
            backgroundImg = backgrounds[currentBgIndex];
            topPipeImg = topPipes[currentBgIndex];
            bottomPipeImg = bottomPipes[currentBgIndex];

            System.out.println("Level Up! Now at Level " + level);
            System.out.println("Gravity: " + gravity + ", Pipe Speed: " + velocityX);
        }
    }

    boolean collision(Bird a, Pipe b) {
        return a.x < b.x + b.width &&   //a's top left corner doesn't reach b's top right corner
                a.x + a.width > b.x &&   //a's top right corner passes b's top left corner
                a.y < b.y + b.height &&  //a's top left corner doesn't reach b's bottom left corner
                a.y + a.height > b.y;    //a's bottom left corner passes b's top left corner
    }

    @Override
    public void actionPerformed(ActionEvent e) { //called every x milliseconds by gameLoop timer
        move();
        repaint();
        if (gameOver) {
            placePipeTimer.stop();
            gameLoop.stop();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            // Play jump sound
            playSound("panchiur.wav");

            velocityY = -9;

            if (gameOver) {
                //restart game by resetting conditions
                bird.y = birdY;
                velocityY = 0;
                pipes.clear();
                gameOver = false;
                score = 0;

                // Reset level system
                level = 1;
                gravity = baseGravity;
                velocityX = basePipeSpeed;
                currentBgIndex = 0;
                backgroundImg = backgrounds[0];
                topPipeImg = topPipes[0];
                bottomPipeImg = bottomPipes[0];

                gameLoop.start();
                placePipeTimer.start();
            }
        }
    }

    //not needed
    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}